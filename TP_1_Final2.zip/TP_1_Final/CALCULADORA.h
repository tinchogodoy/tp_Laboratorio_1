int pedirNumero(char *mensaje,float *resultado);
int sumar(float numeroUno, float numeroDos, float *resultado);
int resta(float numeroUno, float numeroDos, float *resultado);
int division(float numeroUno, float numeroDos, float *resultado);
int multiplicacion(float numeroUno, float numeroDos, float *resultado);
int factorial(int numeroUno, int *resultado);
