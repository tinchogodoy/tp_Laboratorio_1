#include <stdio.h>
#include <stdlib.h>
#define MAXINT 32767
#define MININT -32768
#define MAXFLOAT 3.4E+38
#define MINFLOAT -3.4E+38

/** \brief Pide un numero flotante
 *
 * \param mensaje char* va el mensaje para pedir un numero
 * \param resultado float* devuelve un numero flotante
 * \return int !=0 es numero; !=1 no es numero
 *
 */
int pedirNumero(char* mensaje,float* resultado)
{
    int retorno=-9;
    float aux;
    int rtaScanf;
    do
    {
        printf("%s",mensaje);
        fflush(stdin);
        rtaScanf=scanf("%7f",&aux);
        if(rtaScanf!=1)
        {
            printf("Ingrese solo numeros \n");
            continue;
        }
         retorno=0;
         *resultado=aux;
     }while(retorno!=0);
    return retorno;
}

/** \brief Suma dos flotantes
 *
 * \param int es el primer numero a ser sumado
 * \param int es el segundo numero a ser sumado
 * \param int* es el resultado de la operacion pasado por referencia
 * \return int 0= ok, -1 Error de desborde
 *
 */
int sumar(float numeroUno, float numeroDos, float *resultado)
{
    double resultadoAuxiliar;
    int flagRetorno = -9;
    resultadoAuxiliar = numeroUno+numeroDos;
    if(resultadoAuxiliar <= MAXFLOAT && resultadoAuxiliar >= MINFLOAT)
    {
        *resultado = resultadoAuxiliar;
        flagRetorno = 0;
    }
    else
    {
        flagRetorno=-1;
        printf("Error de desborde! ");
    }
    return flagRetorno;
}

/** \brief resta dos flotantes
 *
 * \param numeroUno float es el primer numero a ser restado
 * \param numeroDos float es el segundo numero a ser restado
 * \param resultado float* es el resultado de la operacion pasado por referencia
 * \return int -1 Error overflow, 0 OK
 *
 */
int resta(float numeroUno, float numeroDos, float *resultado)
{
    double resultadoAuxiliar;
    int flagRetorno = -9;
    resultadoAuxiliar = numeroUno-numeroDos;
    if(resultadoAuxiliar <= MAXFLOAT && resultadoAuxiliar >= MINFLOAT)
    {
        *resultado = resultadoAuxiliar;
        flagRetorno = 0;
    }
    else
    {
        flagRetorno=-1;
        printf("Error de desborde! ");
    }
    return flagRetorno;
}

/** \brief divide dos flotantes
 *
 * \param numeroUno float es el dividendo
 * \param numeroDos float es el divisor
 * \param resultado float* entrega el cociente
 * \return float 0= OK; -1= error overflow; -2=error division por cero
 *
 */
int division(float numeroUno, float numeroDos, float* resultado)
{
    double resultadoAuxiliar;
    int flagRetorno = -9;
    if(numeroDos!=0 )
    {
        resultadoAuxiliar = numeroUno/numeroDos;
        if(resultadoAuxiliar <= MAXFLOAT && resultadoAuxiliar >= MINFLOAT )
        {
            *resultado = resultadoAuxiliar;
            flagRetorno = 0;
        }
        else
        {
            flagRetorno=-1;
            printf("Error de desborde! ");
        }
    }
    else
    {
        flagRetorno=-2;
        printf("Error! ");
    }
    return flagRetorno;
}
/** \brief Multiplica dos numeros flotantes
 *
 * \param numeroUno float es el primer factor
 * \param numeroDos float es el segundo factor
 * \param resultado float* es el producto
 * \return int 0=OK; -1= error de overflow
 *
 */
int multiplicacion(float numeroUno, float numeroDos, float *resultado)
{
    double resultadoAuxiliar;
    int flagRetorno = -9;
    resultadoAuxiliar = numeroUno*numeroDos;
    if(resultadoAuxiliar <= MAXFLOAT && resultadoAuxiliar >= MINFLOAT)
    {
        *resultado = resultadoAuxiliar;
        flagRetorno = 0;
    }
    else
    {
        flagRetorno=-1;
        printf("Error de desborde! ");
    }
    return flagRetorno;
}
/** \brief Calcula el factorial de un entero
 *
 * \param numeroUno int es el numero para factorial
 * \param resultado int* devuelve el factorial del numero
 * \return int 0=OK; -1=Error de overflow; -2=Error numero introducido menor igual que cero o muy grande
 *
 */
int factorial(int numeroUno, int *resultado)
{
    long resultadoAuxiliar=1;
    int flagRetorno = -9;
    int i;
    if(numeroUno>0 && numeroUno<10)
    {
        for(i=1; i<=numeroUno; i++)
        {
            resultadoAuxiliar=resultadoAuxiliar*i;
        }
        if(resultadoAuxiliar <= MAXINT && resultadoAuxiliar >= MININT)
        {
            *resultado = resultadoAuxiliar;
            flagRetorno = 0;
        }
        else
        {
            flagRetorno=-1;
            printf("Error de desborde! ");
        }
    }
    else
    {
        flagRetorno=-2;
        printf("Error! ");
    }
    return flagRetorno;
}
